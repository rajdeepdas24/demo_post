// To find the max number in an array

// let arr1 = [4, 9, 1, 11, 6, 7, 10]; //array

// let max = arr1[0];

// for (let i = 1; i < arr1.length; i++) {
//     if (arr1[i] > max) {
//         max = arr1[i];
//     }
// }
// console.log("The array is:", arr1);
// console.log("Maximum number:", max);


let arr1 = [4, 8, 2, 11, 6, 7, 10];

function findMax(arr1) {
    let max = arr1[0];
    

    for (let i = 1; i < arr1.length; i++) {
        if (arr1[i] > max) {
            max = arr1[i];
        }
    }

    return max;
}
console.log("The array is:", arr1);
console.log("Maximum number:", findMax(arr1));

// To find sum of all elements in an array

let arr2 = [3, 9, 10, 6, 12,7];
console.log("The array is:", arr2);

// using function

let findSum = function(arr2) {
    let sum2 = 0;

    for (let i = 0; i < arr2.length; i++) {
        sum2 = sum2 + arr2[i];
    }
    return sum2;
};

console.log("Sum of all elements:", findSum(arr2));

// to count the odd numbers

let arr3 = [9,1,5,2,6,3,8];
let count = 0;

for(let i = 0; i < arr3.length; i++){
    if( arr3[i] % 2 != 0 ){
        count++;
    }
}
console.log("The array is:", arr3);
console.log("There are total", count, "odd number");


