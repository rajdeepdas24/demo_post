--> Laundry Mart Login Page
This was my task 6...
This task is a responsive Laundry Mart Login Page created using HTML and CSS.


Through this task, I learned:

1. CSS Flexbox layout
2. Styling buttons and input fields
3. Creating responsive user interfaces

--> How to Run

1. Download or clone the repository to your local machine.
2. Open the project folder.
3. Ensure the following files are present:
   * `index.html`
   * `style.css`
   * `README.md`
4. Open `index.html` in any modern web browser such as Google Chrome, Microsoft Edge.
5. The webpage will load automatically with all styles applied from `style.css`.

