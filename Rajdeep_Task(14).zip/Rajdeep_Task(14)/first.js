let n=9;
sum=0;
console.log('There are ', n,' number of terms');

// Sum of n numbers

for(let i=0; i<=n; i++){
    sum+=i;    
}
console.log('The sum of ', n,' terms: ',sum);

// multiplication table
 
let m=1;

console.log('The multiplication table of ',n );

for(let i=1; i<=10; i++){
    m=n*i;
    console.log(n,'x', i,'=', m);
}

// Prime number

let isPrime = true;

if (n <= 1) {
    isPrime = false;
} else {
    for (let i = 2; i < n; i++) {
        if (n % i === 0) {
            isPrime = false;
            break;
        }
    }
}

if (isPrime) {
    console.log(n,'is a prime number');
} else {
    console.log(n,"is not a prime number");
}

// Factors

console.log("Factors of", n, ":");

for (let i = 1; i <= n; i++) {
    if (n % i === 0) {
        console.log(i);
    }
}

// sum of all digits

let number = 782;
console.log("The number is:",number);

let sum1 = 0;

while (number > 0) {
    let digit = number % 10;
    sum1 = sum1 + digit;
    number = (number - digit) / 10;
}

console.log("Sum of digits =", sum1);

// Armstrong number

let num = 153;
let sum2 = 0;

console.log("Let us take a number:",num);

for (let temp1 = number; temp1 > 0;) {
    let digit2 = temp1 % 10;
    sum2 = sum2 + digit1 ** 3;
    temp1 = (temp1 - digit2) / 10;
}

if (sum2 === num) {
    console.log(num, "is an Armstrong number");
} else {
    console.log(num, "is not an Armstrong number");
}