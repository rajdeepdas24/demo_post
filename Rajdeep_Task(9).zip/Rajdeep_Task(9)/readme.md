--> Task 9

Laundry service button interactive.


--> Task structure


Task 9
├── index.html
├── index.css
└── README.md

--> Files

* `index.html` – Contains the structure of the webpage.
* `index.css` – Contains all styling and responsive design rules.
* `README.md` – Project documentation.

--> How to Run?

1. Download or clone the project.
2. Ensure `index.html` and `index.css` are in the same folder.
3. Open `index.html` in any modern web browser.
4. Resize the browser window to test the responsive layouts.
* Desktop View: Above 768px
* Tablet View: 481px – 768px
* Mobile View: 480px and below

