#  Laundry Mart

Task -20

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6)
- EmailJS


## Task Structure

Laundry-Mart
│
├── index.html
├── style.css
├── script.js
|── README.md



## Installation

1. download the zip file


2. Open the project folder.

3. Open `index.html` in your browser.


## How It Works

1. Browse available laundry services.
2. Click **Add Item** to add services to the cart.
3. The cart updates automatically.
4. Total amount is calculated.
5. Fill in your:
   - Full Name
   - Email ID
   - Phone Number
6. Click **Book Now**.
7. A confirmation email is sent using EmailJS.
