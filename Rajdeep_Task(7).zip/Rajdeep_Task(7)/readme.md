
--> Task 7

This project is a responsive landing page for Laundry Mart. 

--> Task structure

Task 7
├── index.html
├── index.css
└── README.md

--> How to Run

1. Download or clone the project files.
2. Open the project folder.
3. Open `index.html` in any modern web browser.
4. Resize the browser window or use developer tools to view responsive layouts.
* Laptop/desktop: Above 768px.
* Tablet: 768px and below.
* Mobile: 425px and below.