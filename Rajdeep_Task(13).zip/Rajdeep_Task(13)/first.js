let a = 1;
let c = 5;
let d = 16;
let f = 8;

console.log('a = 1');
console.log('c = 5');
console.log('d = 16');
console.log('f = 8');


if(a%2===0) {
    console.log('a is an even number');
}
else{
    console.log('a is an odd number');
}

if(c%2===0) {
    console.log('c is an even number');
}
else{
    console.log('c is an odd number');
}

if(d%2===0) {
    console.log('d is an even number');
}
else{
    console.log('d is an odd number');
}

if(f%2===0) {
    console.log('f is an even number');
}
else{
    console.log('f is an odd number');
}