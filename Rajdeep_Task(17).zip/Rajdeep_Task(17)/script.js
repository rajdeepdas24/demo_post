// division function
const divide = (a, b) => {
    return new Promise((resolve, reject) => {
        if (b === 0) {
            reject("Error: Division by zero is not allowed.");
        }
        else {
            resolve(a / b);
        }
    });
};

// Example 1
console.log("Dividing 10 by 2...");

divide(10, 2)
    .then((result) => {
        console.log("Result:", result);
    })
    .catch((error) => {
        console.log(error);
    });

// Example 2
console.log("\nDividing 10 by 0...");

divide(10, 0)
    .then((result) => {
        console.log("Result:", result);
    })
    .catch((error) => {
        console.log(error);
    });

// Example 3
console.log("\nDividing 27 by 3...");

divide(27, 3)
    .then((result) => {
        console.log("Result:", result);
    })
    .catch((error) => {
        console.log(error);
    });

// Example 4
console.log("\nDividing 8 by 0...");

divide(8, 0)
    .then((result) => {
        console.log("Result:", result);
    })
    .catch((error) => {
        console.log(error);
    });

// Example 5
console.log("\nDividing 9 by 3...");

divide(9, 3)
    .then((result) => {
        console.log("Result:", result);
    })
    .catch((error) => {
        console.log(error);
    });