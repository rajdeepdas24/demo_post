This is my 2nd task where I made a website for Laundry Mart.
In this website washing, ironing types of services are available.
I created a price table of each services.
I also created a form where user can book their slots by giving their info.