const students = [
    { id: "001", name: "Riya Sharma", marks: 85, class: "10th", address: "Delhi" },
    { id: "002", name: "Rohan Patel", marks: 70, class: "12th", address: "Mumbai" },
    { id: "003", name: "Rajdeep Das", marks: 91, class: "12th", address: "Bengaluru" },
    { id: "004", name: "Shilpa Roy", marks: 87, class: "12th", address: "Pune" },
    { id: "005", name: "Shivam Singh", marks: 77, class: "12th", address: "Lucknow" },
    { id: "006", name: "Akash Madhwal", marks: 67, class: "12th", address: "Ahmedabad" },
    { id: "007", name: "Rishi Jaat", marks: 74, class: "12th", address: "Chandigarh" },
    { id: "008", name: "Rohit Kumar", marks: 88, class: "12th", address: "Patna" },
    { id: "009", name: "Hritesh Verma", marks: 70, class: "12th", address: "Hyderabad" },
    { id: "010", name: "Rakesh Billa", marks: 80, class: "12th", address: "Pune" },
    { id: "011", name: "Shubham Kumar", marks: 95, class: "12th", address: "Chennai" },
    { id: "012", name: "Akash Puchal", marks: 67, class: "12th", address: "Kochi" },
    { id: "013", name: "Trisha Jaiswal", marks: 78, class: "12th", address: "Jaipur" },
    { id: "014", name: "Drishti Dutta", marks: 65, class: "12th", address: "Guwahati" },
    { id: "015", name: "Urmila", marks: 59, class: "12th", address: "Raipur" }
];

const container = document.querySelector(".container");
const searchBox = document.getElementById("searchBox");
const searchBtn = document.getElementById("searchBtn");
const resultHeading = document.getElementById("resultHeading");

// Function to display cards
function displayStudents(arr) {
    container.innerHTML = arr.map(function(student) {
        return `
        <div class="card">
            <p>Student Name: ${student.name}</p>
            <p>Marks: ${student.marks}%</p>
            <p>Class: ${student.class}</p>
            <p>Address: ${student.address}</p>
        </div>
        `;
    }).join("");
}

// Function to search students
function searchStudents() {

    let text = searchBox.value.trim().toLowerCase();

    let filteredStudents = students.filter(function(student) {
        return student.name.toLowerCase().includes(text);
    });

    if (text === "") {
        resultHeading.textContent = "All Students";
        displayStudents(students);
    } else {
        resultHeading.textContent =
            `Showing ${filteredStudents.length} result(s) for "${searchBox.value}"`;

        displayStudents(filteredStudents);
    }
}

// Initial display
displayStudents(students);

// Search when button is clicked
searchBtn.addEventListener("click", searchStudents);

// Search when Enter key is pressed
searchBox.addEventListener("keydown", function(event) {

    if (event.key === "Enter") {
        searchStudents();
    }

});