This was my task 3 and it was really a good practise of css.
I learnt about styling the background color, font color, even about the id and class and more important about the child case. 
Am learning and excited for the upcoming task.