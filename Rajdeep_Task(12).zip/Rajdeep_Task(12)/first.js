let p = 100000;
let r = 0.0645;
let n = 6;
let t = 3;
let a;
a = p * (1+(r/n)) ** (n*t) ;

console.log("Principle Amount: $", p);
console.log('Rate of Interest: ' , r);
console.log('Interest times in a year: ' , n);
console.log('Time: ', t , ' years');
console.log('Total Interest: ' , a);
